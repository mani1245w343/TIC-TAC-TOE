const cells = document.querySelectorAll('[data-cell]');
const restartButton = document.getElementById('restartButton');
const resultScreen = document.getElementById('result-screen');
const resultMessage = document.getElementById('result-message');
const newGameButton = document.getElementById('newGameButton');
let currentPlayer = 'X';
const winCombinations = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
];

cells.forEach(cell => {
    cell.addEventListener('click', handleClick, { once: true });
});

restartButton.addEventListener('click', restartGame);
newGameButton.addEventListener('click', restartGame);

function handleClick(e) {
    const cell = e.target;
    cell.textContent = currentPlayer;
    if (checkWin(currentPlayer)) {
        showResult(`${currentPlayer} wins!`);
        return;
    }
    if (isDraw()) {
        showResult('Draw!');
        return;
    }
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
}

function checkWin(player) {
    return winCombinations.some(combination => {
        return combination.every(index => {
            return cells[index].textContent === player;
        });
    });
}

function isDraw() {
    return [...cells].every(cell => {
        return cell.textContent === 'X' || cell.textContent === 'O';
    });
}

function showResult(message) {
    resultMessage.textContent = message;
    document.querySelector('.container').classList.add('hidden');
    resultScreen.classList.remove('hidden');
}

function restartGame() {
    cells.forEach(cell => {
        cell.textContent = '';
        cell.removeEventListener('click', handleClick);
        cell.addEventListener('click', handleClick, { once: true });
    });
    currentPlayer = 'X';
    resultScreen.classList.add('hidden');
    document.querySelector('.container').classList.remove('hidden');
}
